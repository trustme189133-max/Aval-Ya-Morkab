package com.ayhan.avalyamorkab

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.*
import kotlin.math.sqrt

class MainActivity : Activity() {
    private val bg = Color.rgb(16,21,34)
    private val panel = Color.rgb(29,38,57)
    private val gold = Color.rgb(246,185,75)
    private val cream = Color.rgb(247,241,226)
    private lateinit var root: LinearLayout
    private lateinit var dragon: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }

    private fun setup(title: String) {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(root); setContentView(scroll)
        addText(title, 27, gold, true)
    }
    private fun home() {
        setup("اول یا مرکب؟")
        addText("راز هر عدد را با اژدهای ریاضی کشف کن",15,cream)
        dragon = addText("🐉",94,cream,true)
        dragon.animate().translationX(-dp(220).toFloat()).setDuration(1).withEndAction {
            dragon.animate().translationX(0f).setDuration(800).setInterpolator(OvershootInterpolator()).start()
        }.start()
        input = EditText(this).apply {
            hint="یک عدد صحیح مثبت وارد کن"; textSize=18f; setTextColor(cream)
            setHintTextColor(Color.LTGRAY); gravity=Gravity.CENTER; inputType=2
            background=rounded(Color.rgb(42,54,77),16); setPadding(dp(12),dp(12),dp(12),dp(12))
        }
        root.addView(input, LinearLayout.LayoutParams(-1,dp(58)).apply { topMargin=dp(16) })
        addButton("بخور اژدها!",gold) { analyze() }
        addButton("آموزش و روش حل مسئله",panel) { guide() }
        addText("این برنامه بدون اینترنت کار می‌کند",12,Color.LTGRAY)
    }
    private fun analyze() {
        val n=input.text.toString().toLongOrNull()
        if(n==null || n<1L) { Toast.makeText(this,"یک عدد صحیح مثبت وارد کن",Toast.LENGTH_SHORT).show(); return }
        val r=facts(n); setup("گزارش اژدها"); addText("🐲",72,cream,true)
        addText(r.first,22,gold,true)
        card("جذر تقریبی",String.format(java.util.Locale.US,"%.4f",sqrt(n.toDouble())))
        card("تعداد مقسوم‌علیه‌های مثبت",r.second.toString())
        card("تجزیه به عوامل اول",r.third)
        card("چطور فهمیدیم؟",r.fourth)
        addButton("بررسی عدد دیگر",gold) { home() }
        addButton("آموزش",panel) { guide() }
    }
    private fun facts(n:Long): Quad {
        if(n==1L) return Quad("عدد ۱ نه اول است و نه مرکب",1,"عدد ۱ عامل اول ندارد","عدد ۱ فقط یک مقسوم‌علیه مثبت دارد.")
        var x=n; var p=2L; var count=1L; val factors= mutableListOf<String>()
        while(p<=x/p) {
            var e=0
            while(x%p==0L) { x/=p; e++ }
            if(e>0) { factors.add(if(e==1) "$p" else "$p^$e"); count*=e+1 }
            p=if(p==2L) 3L else p+2L
        }
        if(x>1) { factors.add("$x"); count*=2 }
        val prime=count==2L
        return Quad(if(prime) "عدد $n اول است ✅" else "عدد $n مرکب است",count,
            factors.joinToString(" × "),
            if(prime) "فقط دو مقسوم‌علیه مثبت دارد: ۱ و خودش." else "بیش از دو مقسوم‌علیه مثبت دارد؛ پس مرکب است.")
    }
    private data class Quad(val first:String,val second:Long,val third:String,val fourth:String)
    private fun guide() {
        setup("آموزش اول و مرکب")
        addText("عدد اول",21,gold,true)
        addText("عدد طبیعی بزرگ‌تر از ۱ که فقط دو مقسوم‌علیه مثبت دارد: ۱ و خودش. مثل ۲، ۳، ۵ و ۷.",16,cream)
        addText("عدد مرکب",21,gold,true)
        addText("عدد طبیعی بزرگ‌تر از ۱ که بیش از دو مقسوم‌علیه مثبت دارد. مثل ۴، ۶، ۸ و ۹.",16,cream)
        addText("نکته مهم",21,gold,true)
        addText("عدد ۱ نه اول است و نه مرکب؛ چون فقط یک مقسوم‌علیه مثبت دارد.",16,cream)
        addText("روش بررسی",21,gold,true)
        addText("برای تشخیص اول بودن، کافی است مقسوم‌علیه‌های احتمالی را تا جذر عدد بررسی کنیم. اگر هیچ‌کدام عدد را تقسیم نکردند، عدد اول است.",16,cream)
        addButton("بازگشت",gold) { home() }
    }
    private fun card(t:String,v:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=rounded(panel,16); setPadding(dp(14),dp(12),dp(14),dp(12)) }
        box.addView(label(t,14,gold,true)); box.addView(label(v,16,cream))
        root.addView(box,LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(7); bottomMargin=dp(7) })
    }
    private fun addText(s:String,size:Int,color:Int,bold:Boolean=false):TextView {
        val v=label(s,size,color,bold); root.addView(v,LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(8); bottomMargin=dp(8) }); return v
    }
    private fun label(s:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); gravity=Gravity.CENTER
        if(bold) setTypeface(typeface,Typeface.BOLD); setLineSpacing(dp(3).toFloat(),1f)
    }
    private fun addButton(s:String,color:Int,action:()->Unit) {
        val b=Button(this).apply { text=s; textSize=16f; isAllCaps=false
            setTextColor(if(color==gold) bg else cream); background=rounded(color,15); setOnClickListener{action()} }
        root.addView(b,LinearLayout.LayoutParams(-1,dp(54)).apply { topMargin=dp(8) })
    }
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply { setColor(c); cornerRadius=dp(r).toFloat() }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
